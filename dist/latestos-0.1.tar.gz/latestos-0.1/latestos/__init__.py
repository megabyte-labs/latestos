from latestos import scraper
from latestos.files import json
